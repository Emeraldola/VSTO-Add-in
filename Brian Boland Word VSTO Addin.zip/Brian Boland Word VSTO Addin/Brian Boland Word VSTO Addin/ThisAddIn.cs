﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Word;
using System.Diagnostics;
using System.Windows.Forms;

namespace Brian_Boland_Word_VSTO_Addin
{
    public partial class ThisAddIn
    {
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            AddGlossaryTaskPane(this.Application.ActiveWindow);
            DocumentSelectionChange(this.Application.ActiveDocument);

            Globals.ThisAddIn.Application.Selection.InsertParagraph();
            Globals.ThisAddIn.Application.Selection.TypeText("selectMe \r\n \r\n");
            Globals.ThisAddIn.Application.Selection.InsertParagraph();
            Globals.ThisAddIn.Application.Selection.TypeText("Selecting the above text will display something in the task pane. Try selecting something else, too. \r\n");
            Globals.ThisAddIn.Application.Selection.TypeText("The task pane freezes (stops updating) after these actions are taken: \r\n");
            Globals.ThisAddIn.Application.Selection.TypeText("1. Close this document without saving. \r\n");
            Globals.ThisAddIn.Application.Selection.TypeText("2. Create a new document. \r\n");
            

            Globals.ThisAddIn.Application.Selection.TypeText("\r\n References Brian found in creating this task pane (Brian doesn't understand the second reference, but it might be useful): ");
            Globals.ThisAddIn.Application.Selection.TypeText("\r\n  https://docs.microsoft.com/en-us/previous-versions/office/developer/office-2007/bb264456(v=office.12)?redirectedfrom=MSDN \r\n");
            Globals.ThisAddIn.Application.Selection.TypeText("\r\n https://social.msdn.microsoft.com/Forums/vstudio/en-US/47fb1e7a-64d3-4467-8c4c-67943b9d7dc3/vsto-document-selectionchange-event-is-not-firing?forum=vsto");
            this.Application.DocumentOpen += new Microsoft.Office.Interop.Word.ApplicationEvents4_DocumentOpenEventHandler(Application_DocumentOpen);
            ((Word.ApplicationEvents4_Event)this.Application).NewDocument += new Microsoft.Office.Interop.Word.ApplicationEvents4_NewDocumentEventHandler(Application_NewDocument);
            this.Application.DocumentChange += new Word.ApplicationEvents4_DocumentChangeEventHandler(Application_DocumentChange);
            this.Application.DocumentBeforeClose += new Microsoft.Office.Interop.Word.ApplicationEvents4_DocumentBeforeCloseEventHandler(Application_MyDocumentClose);
        }

        /// <summary>
        /// Brian used this reference when creating the following methods for opening & closing documents, creating new documents and removing orphaned task panes:
        /// https://docs.microsoft.com/en-us/previous-versions/office/developer/office-2007/bb264456(v=office.12)?redirectedfrom=MSDN
        /// https://social.msdn.microsoft.com/Forums/vstudio/en-US/47fb1e7a-64d3-4467-8c4c-67943b9d7dc3/vsto-document-selectionchange-event-is-not-firing?forum=vsto
        /// 
        /// </summary>


        /// <summary>
        /// Remove unused task panes on document open
        /// </summary>
        /// <param name="Doc"></param>
        private void Application_DocumentOpen(Microsoft.Office.Interop.Word.Document Doc)
        {
            RemoveOrphanedTaskPanes();
            if (this.Application.ShowWindowsInTaskbar)
            {
                // Do not mess with Doc.Activewindow or ActiveDocument!
                AddGlossaryTaskPane(Doc.ActiveWindow); // changed from Doc
                DocumentSelectionChange(this.Application.ActiveDocument); //Doc
            }
            Debug.Print("No. of custom taskpanes: {0}", this.CustomTaskPanes.Count);
        }

        /// <summary>
        /// Bind the event for glossary task pane on new document
        /// </summary>
        /// <param name="Doc"></param>
        private void Application_NewDocument(Microsoft.Office.Interop.Word.Document Doc)
        {
            if (this.Application.ShowWindowsInTaskbar)
            {
                // Do not mess with Doc.Activewindow or ActiveDocument!
                AddGlossaryTaskPane(Doc.ActiveWindow); // changed from Doc
                DocumentSelectionChange(this.Application.ActiveDocument); //Doc
                Globals.ThisAddIn.Application.Selection.TypeText("selectMe \r\n");
                Globals.ThisAddIn.Application.Selection.TypeText("If you closed the previous document without saving, the task pane is not updating in this new document. Please fix my code so the task pane updates.");
            }
        }

        /// <summary>
        /// Remove unused task panes on document change
        /// </summary>
        private void Application_DocumentChange()
        {
            // This is called here instead of from DocumentBeforeClose to avoid errors if user clicks cancel and aborts doc close 
            RemoveOrphanedTaskPanes();
        }

        /// <summary>
        /// Remove unused task panes on document close
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="Cancel"></param>
        private void Application_MyDocumentClose(Word.Document doc, ref bool Cancel)
        {
            if (!Cancel) //TODO: BUG: this runs even if user cancels document close action. Workaround is to remove and then add all task panes again (clicking Show Glossary on the Yogoshu Ribbon)
            {

                DocumentSelectionChangeUnwire(doc); // commenting this out does not solve the "task pane stops updating" problem.
                RemoveOrphanedTaskPanes();
                Debug.Print("Doc close event fired for {0}.", doc.Name);
                Debug.Print("No. of custom taskpanes: {0}", this.CustomTaskPanes.Count);
            }
        }
        /// <summary>
        /// Manage task pane show/hide
        /// </summary>
        public void ShowHideActionPane()
        {
            try
            {
                if (this.Application.ActiveDocument.ProtectionType == Word.WdProtectionType.wdAllowOnlyReading)
                {
                    MessageBox.Show("Glossary is disabled in read-only mode for Word documents.");
                    return;
                }

                Microsoft.Office.Tools.CustomTaskPane ctp = CurrentTaskPane(Application.ActiveWindow);
                if (ctp == null)
                {
                    AddGlossaryTaskPane(Application.ActiveDocument.ActiveWindow);
                    //DocumentSelectionChange(this.Application.ActiveDocument); // adding this line does not solve the "task pane stops updating" problem. (Aug 25)
                }
                else
                {
                    ctp.Visible = true;
                }
                DocumentSelectionChange(this.Application.ActiveDocument); //TODO:  error here if a document downloaded from the internet opens in protected mode - may have been fixed with addition of first if statement in this function
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Remove unused task panes and return current task pane
        /// </summary>
        /// <param name="window"></param>
        /// <returns></returns>
        public Microsoft.Office.Tools.CustomTaskPane CurrentTaskPane(Object window)
        {
            try
            {
                Microsoft.Office.Tools.CustomTaskPane ctp;
                RemoveOrphanedTaskPanes(); // do this to avoid potential errors with null objects
                for (int i = this.CustomTaskPanes.Count; i > 0; i--)
                {
                    if (this.CustomTaskPanes[i - 1].Window.Equals(window))
                    {
                        if (this.CustomTaskPanes[i - 1].Title == "Yogoshu")
                        {
                            ctp = this.CustomTaskPanes[i - 1];
                            return ctp;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return null;
        }

        /// <summary>
        /// Remove unused multiple task panes
        /// </summary>
        private void RemoveOrphanedTaskPanes()
        {
            try
            {
                Microsoft.Office.Tools.CustomTaskPane ctp;
                for (int i = this.CustomTaskPanes.Count; i > 0; i--)
                {
                    ctp = this.CustomTaskPanes[i - 1];
                    try
                    {
                        if (ctp != null & ctp.Window == null) //TODO: Throws an error if ctp was deleted or no longer valid 
                        {
                            this.CustomTaskPanes.Remove(ctp);
                        }
                    }
                    catch { }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        /// <summary>
        /// Add new task pane
        /// </summary>
        /// <param name="Wn"></param>
        public void AddGlossaryTaskPane(Word.Window Wn)
        {
            try
            {
                Microsoft.Office.Tools.CustomTaskPane ctp;
                TaskPaneControl newHost = new TaskPaneControl();
                Globals.ThisAddIn.Application.ScreenUpdating = false;
                ctp = this.CustomTaskPanes.Add(newHost, "Yogoshu", Wn);
                ctp.Visible = true;
                Globals.ThisAddIn.Application.ScreenUpdating = true;
                if (Application.Documents.Count > 0) // adding this line does not fix the "task pane stops updating" problem (Aug 25)
                    DocumentSelectionChange(Wn.Document);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        /// <summary>
        /// Bind event on word document change
        /// </summary>
        /// <param name="doc"></param>
        private void DocumentSelectionChange(Word.Document doc)
        {
            try
            {
                Document vstoDoc = Globals.Factory.GetVstoObject(doc);
                vstoDoc.SelectionChange += new Microsoft.Office.Tools.Word.SelectionEventHandler(ThisAddIn_SelectionChange);
            }
            catch (Exception ex)
            {
                ex.ToString();
                Debug.Print("Exception raised in DocumentSelectionChange in ThisAddin.cs");
            }
        }

        /// <summary>
        /// Unbind event on word document change
        /// </summary>
        /// <param name="doc"></param>
        private void DocumentSelectionChangeUnwire(Word.Document doc)
        {
            // Add try/catch like Document Selection Change?
            try
            {
                Document vstoDoc = Globals.Factory.GetVstoObject(doc);
                vstoDoc.SelectionChange -= ThisAddIn_SelectionChange;

            }
            catch (Exception ex)
            {
                ex.ToString();
                Debug.Print("Exception raised in DocumentSelectionChangeUnwire in ThisAddin.cs");
            }
        }

        private async void ThisAddIn_SelectionChange(object sender, SelectionEventArgs e)
        {
            
            Properties.Settings mySettings = new Properties.Settings();
            object objSentence = Word.WdUnits.wdSentence;

            //Word.Range r = e.Selection.Next(ref objSentence, ref missing);

            Microsoft.Office.Tools.CustomTaskPane myPane = CurrentTaskPane(e.Selection.Application.ActiveWindow);

            if (myPane != null && myPane.Visible == true) // only update task pane if necessary 
            {
                TaskPaneControl myTaskPane = (TaskPaneControl)myPane.Control;
                myTaskPane.WpfElementHost.lblAccountName.Content = String.Format("Account: {0}", mySettings.Email.ToString());
                

                // Text is selected, so do search on selected text 
                if (Globals.ThisAddIn.Application.Selection.Type == Word.WdSelectionType.wdSelectionNormal)
                {
                    // Get highlighted text
                    string selectedText = e.Selection.Text.Trim();

                    // Send highlighted text to Yogoshu task pane
                    List<GlossaryEntry> results = new List<GlossaryEntry>();
                    GlossaryEntry gEntry = new GlossaryEntry();
                    if (selectedText == "selectMe")
                    {
                        gEntry.Source = "selectMe";
                        gEntry.Target = "Good job selecting me";
                        gEntry.UserName = "BTB";
                    }
                    else
                    {
                        gEntry.Source = "You didn't highlight selectMe";
                        gEntry.Target = "Aim better next time";
                        gEntry.UserName = "BTB";
                    }

                    results.Add(gEntry);

                    myTaskPane.WpfElementHost.Dispatcher.Invoke(new System.Action(() =>
                    {
                        myTaskPane.WpfElementHost.ResultsDisplay.Clear();

                        foreach (GlossaryEntry entry in results)
                        {
                            myTaskPane.WpfElementHost.ResultsDisplay.Add(entry);
                        }
                    }));

                }
            }
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            this.Application.DocumentOpen -= new Microsoft.Office.Interop.Word.ApplicationEvents4_DocumentOpenEventHandler(Application_DocumentOpen);
            ((Word.ApplicationEvents4_Event)this.Application).NewDocument -= new Microsoft.Office.Interop.Word.ApplicationEvents4_NewDocumentEventHandler(Application_NewDocument);
            this.Application.DocumentChange -= new Word.ApplicationEvents4_DocumentChangeEventHandler(Application_DocumentChange);
            this.Application.DocumentBeforeClose -= new Microsoft.Office.Interop.Word.ApplicationEvents4_DocumentBeforeCloseEventHandler(Application_MyDocumentClose);
            if (Application.Documents.Count > 0)
            {
                Document vstoDoc = Globals.Factory.GetVstoObject(Application.ActiveDocument);
                vstoDoc.SelectionChange -= ThisAddIn_SelectionChange;
            }
            System.Windows.Threading.Dispatcher.CurrentDispatcher.InvokeShutdown();  // Need this to avoid exception on shutdown
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
