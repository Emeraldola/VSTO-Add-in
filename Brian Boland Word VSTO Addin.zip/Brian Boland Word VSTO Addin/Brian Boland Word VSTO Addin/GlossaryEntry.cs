﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brian_Boland_Word_VSTO_Addin
{
    public class GlossaryEntry : IEquatable<GlossaryEntry>
    {
        string _username = string.Empty;
        string _source = string.Empty;
        string _target = string.Empty;
        string[] _tags = { };
        //DateTime _dateupdated = DateTime.MinValue;
        string _dateupdated = DateTime.MinValue.ToString();
        string _comment = string.Empty;
        int _OrderNo = 0;

        public int OrderNo
        {
            get { return _OrderNo; }
            set { _OrderNo = value; }
        }
        
        public string UserName
        {
            get { return _username; }
            set { _username = value; }
        }

        public string Source
        {
            get { return _source; }
            set { _source = value; }
        }

        public string Target
        {
            get { return _target; }
            set { _target = value; }
        }

        public string[] Tags
        {
            get { return _tags; }
            set { _tags = value; }
        }

        public string DateUpdated
        {
            get { return _dateupdated; }
            set { _dateupdated = value; }
        }

        public string Comment
        {
            get { return _comment; }
            set { _comment = value; }
        }

        string[] _secrettags = { };

        public string[] SecretTags
        {
            get { return _secrettags; }
            set { _secrettags = value; }
        }

        public GlossaryEntry()
        {
        }

        public GlossaryEntry(string username, string source, string target, string[] tags, string[] secrettags, string dateupdated, string comment, int orderNo) //int entryid,
        {
            this.UserName = username;
            this.Source = source;
            this.Target = target;
            this.Tags = tags;
            this.SecretTags = secrettags;
            this.DateUpdated = dateupdated;
            this.Comment = comment;
            this.OrderNo = orderNo;
        }

        public bool Equals(GlossaryEntry other)
        {
            if (Object.ReferenceEquals(other, null)) return false;

            if (Object.ReferenceEquals(this, other)) return true;

            // Copy the tags in order to compare them, but don't mess up their original order in GlossaryEntry
            string[] _Tags = Tags;
            string[] _otherTags = other.Tags;
            Array.Sort(_Tags);
            Array.Sort(_otherTags);

            return Source.Equals(other.Source) && Target.Equals(other.Target) && _Tags.SequenceEqual(_otherTags) && DateUpdated.Equals(other.DateUpdated);
        }

        public bool EqualSources(GlossaryEntry other)
        {
            if (Object.ReferenceEquals(other, null)) return false;

            if (Object.ReferenceEquals(this, other)) return true;

            return Source.Equals(other.Source);

        }

        public bool EqualTargetsSources(GlossaryEntry other)
        {
            if (Object.ReferenceEquals(other, null)) return false;

            if (Object.ReferenceEquals(this, other)) return true;

            return Source.Equals(other.Source) && Target.Equals(other.Target);

        }

        public override int GetHashCode()
        {
            int hashSource = Source.GetHashCode();
            int hashTarget = Target.GetHashCode();
            int hashTags = Tags.GetHashCode();

            return hashSource ^ hashTarget ^ hashTags;
        }

    }
}
