﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brian_Boland_Word_VSTO_Addin
{
    public partial class TaskPaneControl : UserControl
    {
        public TaskPaneControl()
        {
            InitializeComponent(); this.Anchor = AnchorStyles.Top;

            this.SizeChanged += TaskPaneControl_SizeChanged;

            ElementHostHeight = this.Height;
            ElementHostWidth = this.Width;
        }

        void TaskPaneControl_SizeChanged(object sender, EventArgs e)
        {
            ElementHostHeight = this.Height;
            ElementHostWidth = this.Width;

        }

        public int ElementHostHeight
        {
            get
            {
                return this.elementHost1.Height;
            }
            set
            {
                this.elementHost1.Height = value;
            }
        }

        public int ElementHostWidth
        {
            get
            {
                return this.elementHost1.Width;

            }
            set
            {
                this.elementHost1.Width = value;
            }
        }

        public YogoshuTaskPaneXaml WpfElementHost
        {
            get
            {
                return this.yogoshuTaskPaneXaml1;
            }
        }
    }
}
