﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Brian_Boland_Word_VSTO_Addin
{
    [ValueConversion(typeof(string[]), typeof(string))]
    public class ArrayToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //if (targetType != typeof(string))
            //    throw new InvalidOperationException("The target must be a String");

            return String.Join(" | ", (string[])value);

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            return ((string)value).Split('|');
            //throw new NotImplementedException();
        }
    }

    public class SameUserBoolCoverter : IValueConverter
    {
        //GlossaryBusiness logic => new GlossaryBusiness();
        string strThisUser = "";

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            bool boolSameUser = false;
            strThisUser = "BTB";
            string strUserName = (string)value;
            if (strThisUser == strUserName)
                boolSameUser = true;
            return boolSameUser;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return (string)"";
        }

    }
    
    /// <summary>
    /// Interaction logic for YogoshuTaskPaneXaml.xaml
    /// </summary>
    public partial class YogoshuTaskPaneXaml : UserControl
    {
        public ObservableCollection<GlossaryEntry> ResultsDisplay { get; set; }

        public YogoshuTaskPaneXaml()
        {
            InitializeComponent();
            ResultsDisplay = new ObservableCollection<GlossaryEntry>();
            GetGlossary();
        }

        private void GetGlossary()
        {
            try
            {
                ListCollectionView UserCollection = new ListCollectionView(ResultsDisplay);
                //GlossaryDataGrid.Dispatcher.Invoke(() => { GlossaryDataGrid.ItemsSource = ResultsDisplay; });
                UserCollection.GroupDescriptions.Add(new PropertyGroupDescription("UserName"));
                GlossaryDataGrid.ItemsSource = UserCollection;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        private void Label_MouseEnter(object sender, MouseEventArgs e)
        {
            Label myLabel = (Label)sender;
            myLabel.Foreground = new SolidColorBrush(Colors.Black);

        }

        private void Label_MouseLeave(object sender, MouseEventArgs e)
        {
            Label myLabel = (Label)sender;
            myLabel.Foreground = new SolidColorBrush(Colors.LightGray);

        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            MenuItem myMenuItem = e.OriginalSource as MenuItem;
            string strSource = myMenuItem.CommandParameter.ToString();

            // send Source to form for editing entry
            //EditGlossaryForm editForm = new EditGlossaryForm();
            //editForm.txtSource.Text = strSource;
            //editForm.btnSearch.PerformClick();
            //editForm.Show();
        }

        private void Label_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Controls.Label lblClickedTarget = (System.Windows.Controls.Label)sender;
            string strTarget = ((System.Windows.Controls.TextBlock)(lblClickedTarget.Content)).Text;

            Globals.ThisAddIn.Application.Selection.TypeText(strTarget + " ");

            //Globals.ThisAddIn.Application.Selection.Document.Activate();
        }
    }
}
